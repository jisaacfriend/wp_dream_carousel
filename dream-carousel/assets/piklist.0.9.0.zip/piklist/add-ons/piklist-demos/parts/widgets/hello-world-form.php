<?php

  piklist('field', array(
    'type' => 'text'
    ,'field' => 'from'
    ,'label' => __('From')
    ,'value' => 'Piklist'
  ));

?>