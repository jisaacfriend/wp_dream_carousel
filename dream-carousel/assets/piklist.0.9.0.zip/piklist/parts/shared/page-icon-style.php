
<style type="text/css">
  /* Page Icon */

  <?php echo esc_attr($page_icon_id); ?> {
    background-image: url('<?php echo esc_url($icon_url) ?>') !important;
    background-repeat: no-repeat !important;
    background-position: 0 0 !important;
    background-size: 34px 30px !important;
  }
</style>
